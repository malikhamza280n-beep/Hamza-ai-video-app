# Hamza Real AI Video App

A mobile-first Express app connected to the Runway Dev API.

Features:
- Story/prompt to real AI video
- Optional character/reference image
- 16:9 YouTube, 9:16 Shorts/Reels/TikTok, 1:1
- 5 or 10 second clips
- Real MP4 output URL
- Runway API key kept in server environment variable

Required environment variable:
RUNWAYML_API_SECRET

Start:
npm install
npm start
