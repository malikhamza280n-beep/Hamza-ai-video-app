import express from "express";
import multer from "multer";
import RunwayML, { TaskFailedError } from "@runwayml/sdk";
import fs from "fs";
import os from "os";
import path from "path";
import crypto from "crypto";
import { execFile } from "child_process";
import { promisify } from "util";
import ffmpegPath from "ffmpeg-static";

const execFileAsync = promisify(execFile);
const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 }
});

app.use(express.json({ limit: "2mb" }));

const html = `<!doctype html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Hamza AI Video</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#0b1020;color:#fff}
.wrap{max-width:760px;margin:auto;padding:18px}.card{background:#151c31;border:1px solid #283451;border-radius:20px;padding:18px;margin-bottom:14px}
h1{margin:0 0 6px;font-size:25px}.sub{color:#aab5ce;font-size:14px;margin-bottom:18px}
label{display:block;font-size:14px;font-weight:700;margin:14px 0 7px}textarea,input,select{width:100%;border:1px solid #35415e;background:#0d1426;color:#fff;border-radius:12px;padding:12px;font:inherit}
textarea{min-height:145px;resize:vertical}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
button{width:100%;border:0;border-radius:13px;padding:14px;font-weight:800;font-size:16px;background:#fff;color:#101522;margin-top:16px}
button:disabled{opacity:.5}.preview{display:none;width:100%;border-radius:14px;margin-top:14px}.status{margin-top:14px;padding:12px;border-radius:12px;background:#0d1426;color:#cbd5e1;white-space:pre-wrap;font-size:14px}
a.download{display:none;margin-top:14px;text-align:center;background:#fff;color:#101522;padding:13px;border-radius:12px;font-weight:800;text-decoration:none}
.small{font-size:12px;color:#93a1bd;margin-top:8px;line-height:1.45}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>🎬 Hamza AI Video</h1>
    <div class="sub">Real AI video generator — story + character image → MP4</div>

    <label>Story / scene prompt</label>
    <textarea id="story" placeholder="Example: Rayyan walks through a magical forest, sees a glowing rabbit, smiles and follows it toward a bright waterfall."></textarea>

    <label>Character / reference image (optional)</label>
    <input id="image" type="file" accept="image/png,image/jpeg,image/webp">

    <div class="row">
      <div>
        <label>Format</label>
        <select id="ratio">
          <option value="1280:720">16:9 YouTube</option>
          <option value="720:1280">9:16 Shorts / Reels / TikTok</option>
          <option value="960:960">1:1 Square</option>
        </select>
      </div>
      <div>
        <label>Clip length</label>
        <select id="duration">
          <option value="5">5 seconds</option>
          <option value="10">10 seconds</option>
        </select>
      </div>
    </div>

    <button id="go">Generate real AI video</button>
    <div class="status" id="status">Ready.</div>
    <video id="video" class="preview" controls playsinline></video>
    <a id="download" class="download" download="hamza-ai-video.mp4">⬇️ Save MP4</a>
    <div class="small">Your Runway API key stays on the server. Never paste it into this page.</div>
  </div>
</div>
<script>
const $=id=>document.getElementById(id);
$("go").onclick=async()=>{
  const story=$("story").value.trim();
  if(!story){$("status").textContent="Pehle story/prompt likho.";return}
  const file=$("image").files[0];
  if(file && file.size>8*1024*1024){$("status").textContent="Image 8 MB se chhoti honi chahiye.";return}
  $("go").disabled=true;$("download").style.display="none";$("video").style.display="none";
  $("status").textContent="⏳ AI video generate ho rahi hai... 2–10 seconds ki clip ko thora time lag sakta hai.";
  try{
    const fd=new FormData();fd.append("story",story);fd.append("ratio",$("ratio").value);fd.append("duration",$("duration").value);
    if(file)fd.append("image",file);
    const r=await fetch("/api/generate",{method:"POST",body:fd});
    const data=await r.json();
    if(!r.ok)throw new Error(data.error||"Generation failed");
    $("status").textContent="✅ Video ready!";
    $("video").src=data.videoUrl+"?t="+Date.now();$("video").style.display="block";
    $("download").href=data.videoUrl;$("download").style.display="block";
  }catch(e){$("status").textContent="❌ "+e.message}
  finally{$("go").disabled=false}
};
</script>
</body></html>`;

app.get("/", (_req,res) => res.type("html").send(html));

function dataUriFromBuffer(file) {
  const mime = file.mimetype || "image/jpeg";
  return `data:${mime};base64,${file.buffer.toString("base64")}`;
}

app.post("/api/generate", upload.single("image"), async (req,res) => {
  try {
    if (!process.env.RUNWAYML_API_SECRET) {
      return res.status(500).json({error:"Server is missing RUNWAYML_API_SECRET."});
    }
    const story = String(req.body.story || "").trim();
    if (!story) return res.status(400).json({error:"Story is required."});

    const ratio = ["1280:720","720:1280","960:960"].includes(req.body.ratio)
      ? req.body.ratio : "1280:720";
    const duration = Number(req.body.duration) === 10 ? 10 : 5;

    const client = new RunwayML();
    const promptText =
      "Create a polished animated story shot for a children's YouTube video. " +
      "Keep the character's appearance consistent with the reference image when provided. " +
      "Natural cinematic movement, clear subject, pleasant lighting, no subtitles, no logos. " +
      "Story action: " + story;

    const input = {
      model: "gen4.5",
      promptText,
      ratio,
      duration
    };
    if (req.file) input.promptImage = dataUriFromBuffer(req.file);

    const task = await client.imageToVideo.create(input).waitForTaskOutput({timeout: 9*60*1000});
    const videoUrl = task.output?.[0];
    if (!videoUrl) throw new Error("Runway completed but returned no video URL.");

    return res.json({ok:true, videoUrl});
  } catch (err) {
    let message = err?.message || "Video generation failed.";
    if (err instanceof TaskFailedError) {
      message = err.taskDetails?.failure || err.taskDetails?.failureCode || message;
    }
    console.error(err);
    res.status(500).json({error: message});
  }
});

app.get("/health", (_req,res)=>res.json({ok:true, app:"Hamza AI Video"}));

app.listen(PORT, ()=>console.log(`Hamza AI Video running on port ${PORT}`));
