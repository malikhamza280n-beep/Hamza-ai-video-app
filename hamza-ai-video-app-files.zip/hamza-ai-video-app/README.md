# Hamza AI Video

Real mobile-first AI video web app using Runway Gen-4.5 through a secure server.

## Render
Build command: `npm install`
Start command: `npm start`
Environment variable: `RUNWAYML_API_SECRET` = your Runway API key
