import express from 'express';
import RunwayML from '@runwayml/sdk';

const app = express();
const PORT = process.env.PORT || 10000;
const client = new RunwayML({ apiKey: process.env.RUNWAYML_API_SECRET });

app.use(express.json({ limit: '12mb' }));
app.use(express.static('public'));

app.get('/health', (req, res) => res.json({ ok: true, app: 'Hamza AI Video' }));

app.post('/api/generate', async (req, res) => {
  try {
    if (!process.env.RUNWAYML_API_SECRET) {
      return res.status(500).json({ error: 'Runway API key is not configured on the server.' });
    }

    const { story, imageData, ratio = '16:9', duration = 5 } = req.body || {};
    if (!story?.trim()) return res.status(400).json({ error: 'Story/prompt is required.' });

    const runwayRatio = ratio === '9:16' ? '720:1280' : '1280:720';
    const seconds = Number(duration) === 10 ? 10 : 5;

    const input = {
      model: 'gen4.5',
      promptText: story.trim(),
      ratio: runwayRatio,
      duration: seconds
    };
    if (imageData) input.promptImage = imageData;

    const task = await client.imageToVideo.create(input).waitForTaskOutput();
    const videoUrl = Array.isArray(task?.output) ? task.output[0] : null;

    if (!videoUrl) return res.status(502).json({ error: 'Runway completed without returning a video URL.', task });
    res.json({ ok: true, videoUrl, task });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error?.message || 'Video generation failed.' });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`Hamza AI Video running on port ${PORT}`));
